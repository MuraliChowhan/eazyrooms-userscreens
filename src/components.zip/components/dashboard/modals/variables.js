const MY_LIST = {
    APPOINTMENT: "New Appointments",
    CLIENT: "Add clients",
    MESSAGES: "Send message",
    MAIL: "Send mail",
    INVOICE: "New Invoice",
  };
  
  export {
    MY_LIST
  };
  