import Dashboard from "./Dashboard";
import QuickLinks from "./QuickLinks";

function DashboardIndex() {
    return (
        <div className="dashboardmain">
            <Dashboard />
        </div>
    );
}

export default DashboardIndex;
