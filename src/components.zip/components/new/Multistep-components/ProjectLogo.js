import React, { useState } from 'react';

function ProjectLogo(props) {

    return (
        <>
            <div className="d-flex align-items-center">
                <div>
                    <img src="./item.jpg" style={{ borderRadius: "6px" }} width="60px" height="60px" />
                </div>
                <div style={{ fontSize: "18px", lineHeight: "22px", marginLeft: "10px", fontWeight: 500 }}>
                    Hungrr
                </div>
            </div>
        </>
    );
}

export default ProjectLogo;
