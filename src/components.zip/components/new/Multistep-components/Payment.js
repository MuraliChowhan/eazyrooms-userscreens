import React, { useState } from "react";

const Payment = (props) => {
    return (
        <div>
            Payment
        </div>

    );
};

export default Payment;