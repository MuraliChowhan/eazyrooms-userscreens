import React, { useState } from "react";
import './sidebar.css';
function ListItemsDetails(props) {

    const { sidebarItems, filteredData } = props;
    const [parkingCount, setParkingCount] = useState(0);
    const handleIncrement = () => {
        setParkingCount(prevCount => prevCount + 1);
    };
    const handleDecrement = () => {
        setParkingCount(prevCount => prevCount - 1);
    };

    return (
        <>
            <div className="pt-2">
                <div style={{ fontSize: "20px", lineHeight: "32px", fontWeight: "500" }} className="itemNames my-3">Chilli Chicken
                    <span style={{ fontSize: "20px", lineHeight: "32px", fontWeight: 500 }}>

                        <span style={{ marginLeft: "10px" }} className="custom-badge">4</span>
                    </span>
                </div>

                <div className="media d-flex align-items-center mb-4">
                    <img className="mr-3 border rounded" width="120px" height="100px" src="./3.jpg" alt="Generic placeholder image" />
                    <div className="media-body w-100" style={{ marginLeft: "12px" }}>
                        <div className="d-flex justify-content-between align-items-center">
                            <span className="d-flex align-items-center" style={{ fontSize: "17px", fontWeight: "500", }}>
                                <span className="square-box" style={{ marginRight: "5px" }}> <span className="dot"></span> </span>   Chicken Biryani
                            </span>
                            <div className="col-sm-12 col-md-3 d-flex justify-content between bid-plus-minus">
                                <div className="bid-minus cursor-pointer"
                                    onClick={handleDecrement}
                                >-</div>
                                <div className="bid-money mt-1 cursor-pointer">
                                    {
                                        parkingCount === 0 ? 0 : parkingCount
                                    }
                                </div>
                                <div className="bid-plus cursor-pointer"
                                    onClick={handleIncrement}
                                >+</div>
                            </div>
                        </div>
                        <div className="cost-text mb-2">&#8377; 40</div>
                    </div>
                </div>

                {
                    filteredData?.map((item, index) =>
                        <div>
                            <div key={index} className="media d-flex align-items-center mb-4">
                                <img className="mr-3 border rounded" width="120px" height="100px" src={item.img} alt="Generic placeholder image" />
                                <div className="media-body w-100" style={{ marginLeft: "12px" }}>
                                    <div className="d-flex justify-content-between align-items-center">
                                        <span className="d-flex align-items-center" style={{ fontSize: "17px", fontWeight: "500", }}>
                                            <span className="square-box" style={{ marginRight: "5px" }}> <span className="dot"></span> </span>   {item.name}
                                        </span>
                                        <div className="col-sm-12 col-md-3 d-flex justify-content between bid-plus-minus">
                                            <div className="bid-minus cursor-pointer"
                                                onClick={handleDecrement}
                                            >-</div>
                                            <div className="bid-money mt-1 cursor-pointer">
                                                {
                                                    parkingCount >= 0 ? 0 : parkingCount
                                                }
                                            </div>
                                            <div className="bid-plus cursor-pointer"
                                                onClick={handleIncrement}
                                            >+</div>
                                        </div>
                                    </div>
                                    <div className="cost-text mb-2">&#8377; {item.cost}</div>
                                </div>
                            </div>
                            <div key={index} className="media d-flex align-items-center mb-4">
                                <img className="mr-3 border rounded" width="120px" height="100px" src="./3.jpg" alt="Generic placeholder image" />
                                <div className="media-body w-100" style={{ marginLeft: "12px" }}>
                                    <div className="d-flex justify-content-between align-items-center">
                                        <span className="d-flex align-items-center" style={{ fontSize: "17px", fontWeight: "500", }}>
                                            <span className="square-box" style={{ marginRight: "5px" }}> <span className="dot"></span> </span>   Chicken Biryani
                                        </span>
                                        <div className="col-sm-12 col-md-3 d-flex justify-content between bid-plus-minus">
                                            <div className="bid-minus cursor-pointer"
                                                onClick={handleDecrement}
                                            >-</div>
                                            <div className="bid-money mt-1 cursor-pointer">
                                                {
                                                    parkingCount >= 0 ? 0 : parkingCount
                                                }
                                            </div>
                                            <div className="bid-plus cursor-pointer"
                                                onClick={handleIncrement}
                                            >+</div>
                                        </div>
                                    </div>
                                    <div className="cost-text mb-2">&#8377; 40</div>
                                </div>
                            </div>
                        </div>
                    )
                }
            </div>
        </>
    );
}

export default ListItemsDetails;
